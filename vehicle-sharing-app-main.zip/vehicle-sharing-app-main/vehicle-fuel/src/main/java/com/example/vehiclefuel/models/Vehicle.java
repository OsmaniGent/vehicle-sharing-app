package com.example.vehiclefuel.models;

public class Vehicle {

}
