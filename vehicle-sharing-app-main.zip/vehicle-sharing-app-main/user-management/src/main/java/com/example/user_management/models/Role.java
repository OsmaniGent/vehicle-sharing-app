package com.example.user_management.models;

public enum Role {

    DRIVER,
    PASSENGER

}
